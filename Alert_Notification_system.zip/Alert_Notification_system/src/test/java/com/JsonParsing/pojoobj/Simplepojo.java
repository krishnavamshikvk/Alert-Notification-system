package com.JsonParsing.pojoobj;

public class Simplepojo {

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String title;
}
