package com.JsonParsing;


import AlertNotification.EventStateInfo;
import AlertNotification.landmark;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

class JsonTest {

    private String src = "{\"EVENT_TYPE_CODE\":\"MOVE_PER\",\"currentState\":{\"speed\":50,\"odometer\":30000,\"typePressure\":30,\"landmarks\":[{\"id\":1,\"place\":\"a\"},{\"id\":2,\"place\":\"b\"},{\"id\":3,\"place\":\"c\"}]},\"previousState\":{\"speed\":55,\"odometer\":29999,\"typePressure\":30}}";



    @Test
    void StateInfoparse() throws JsonProcessingException {
        JsonNode node =Json.parse(src);
        EventStateInfo pojo = Json.fromJson(node,EventStateInfo.class);


    }
}