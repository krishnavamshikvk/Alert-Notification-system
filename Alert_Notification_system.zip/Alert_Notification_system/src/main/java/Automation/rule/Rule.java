package Automation.rule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Rule {

    private List<Condition> conditions;

    private String output;

    private String rulename;

    public String getRulename() {
        return rulename;
    }

    public void setRulename(String rulename) {
        this.rulename = rulename;
    }

    public List<Condition> getConditions() {
        return conditions;
    }

    public void setConditions(List<Condition> conditions) {
        this.conditions = conditions;
    }


    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    @Override
    public String toString(){
        StringBuilder statementBuilder = new StringBuilder();

        for (Condition condition : getConditions()) {

            String operator = null;

            switch (condition.getOperator()) {
                case EQUAL_TO:
                    operator = "==";
                    break;
                case NOT_EQUAL_TO:
                    operator = "!=";
                    break;
                case GREATER_THAN:
                    operator = ">";
                    break;
                case LESS_THAN:
                    operator = "<";
                    break;
                case GREATER_THAN_OR_EQUAL_TO:
                    operator = ">=";
                    break;
                case LESS_THAN_OR_EQUAL_TO:
                    operator = "<=";
                    break;
            }

            String operation = null;

            switch (condition.getOperation()) {
                case AND:
                    operation = "&&";
                    break;
                case OR:
                    operation = "||";
                    break;
            }

            statementBuilder.append(condition.getField()).append(" ").append(operator).append(" ");

            switch (condition.getValuetype()) {
            case LIST: {

                List<String> a = (List<String>) condition.getValue();

                  for (String aa : a) {

                             statementBuilder.append(condition.getValue()).append(" ").append(condition.getField());
                            }
                        }

                    }

            if (condition.getValue() instanceof String) {
                statementBuilder.append("'").append(condition.getValue()).append("'");
            } else {
                statementBuilder.append(condition.getValue());
            }

            statementBuilder.append(" ").append(operation).append(" ");
        }


        String statement = statementBuilder.toString();

        return statement.substring(0, statement.length() - 4);
    }

    }


