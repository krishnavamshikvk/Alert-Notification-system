package Automation.rule;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class Ruleset {

    public static List<Rule> getruleset(){
        List<Rule> rules = new ArrayList<>();

        List<Condition> condlist = Conditionset.getconditions();

        Map<String, List<Condition>> conditiongroup = condlist.stream().collect(Collectors.groupingBy(w -> w.getRulename()));


       for (Map.Entry<String,List<Condition>> me :
                conditiongroup.entrySet())
       {
           Rule rule1 = new Rule();
           List<Condition> listcond = me.getValue();
           rule1.setConditions(listcond);
           rule1.setOutput(listcond.get(0).getOutput());
           rules.add(rule1);
        }

        return rules;  // returning the rules as list
    }

}
