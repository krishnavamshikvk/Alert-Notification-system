package Automation.rule;

import java.util.HashMap;
import java.util.Map;

public class Condition {

    private String field;
    private Object value;

    private ValueType valuetype;
    private Condition.Operator operator;

    private Condition.Operation operation;

    private String rulename;

    private String eventname;

    private String output;


    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public ValueType getValuetype() { return valuetype;}

    public void setValuetype(ValueType valuetype) { this.valuetype = valuetype;}

    public Condition.Operator getOperator() {
        return operator;
    }

    public void setOperator(Condition.Operator operator) {
        this.operator = operator;
    }

    public Condition.Operation getOperation() {
        return operation;
    }

    public void setOperation(Condition.Operation operation) {
        this.operation = operation;
    }

    public String getRulename() {
        return rulename;
    }

    public void setRulename(String rulename) {
        this.rulename = rulename;
    }

    public String getEventname() {
        return eventname;
    }

    public void setEventname(String eventObjectname) {
        this.eventname = eventObjectname;
    }


    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public static enum Operator {
        NOT_EQUAL_TO("NOT_EQUAL_TO"),
        EQUAL_TO("EQUAL_TO"),
        GREATER_THAN("GREATER_THAN"),
        LESS_THAN("LESS_THAN"),
        GREATER_THAN_OR_EQUAL_TO("GREATER_THAN_OR_EQUAL_TO"),
        LESS_THAN_OR_EQUAL_TO("LESS_THAN_OR_EQUAL_TO");
        private final String value;
        private static Map<String, Operator> constants = new HashMap<String, Operator>();

        static {
            for (Condition.Operator c : values()) {
                constants.put(c.value, c);
            }
        }

        private Operator(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return this.value;
        }

        public static Condition.Operator fromValue(String value) {
            Condition.Operator constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }
    }

    public static enum Operation {
        AND("AND"),
        OR("OR");
        private final String value;
        private static Map<String, Operation> constants = new HashMap<String, Operation>();

        static {
            for (Condition.Operation c : values()) {
                constants.put(c.value, c);
            }
        }

        private Operation(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return this.value;
        }

        public static Condition.Operation fromValue(String value) {
            Condition.Operation constant = constants.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }
    }


}
