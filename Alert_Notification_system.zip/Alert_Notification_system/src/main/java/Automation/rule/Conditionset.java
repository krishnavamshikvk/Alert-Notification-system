package Automation.rule;

import java.util.ArrayList;
import java.util.List;

import Automation.rule.ValueType;

public class Conditionset {

    public static List<Condition> getconditions() {


        List<Condition> listc = new ArrayList<>();

        Condition condition1 = new Condition();
        condition1.setField("assetId");
        condition1.setOperator(Condition.Operator.EQUAL_TO);
        condition1.setValue("MOVE_PER");
        condition1.setValuetype(ValueType.DOUBLE);
        condition1.setOperation(Condition.Operation.OR);
        condition1.setRulename("OVERSPEEDEVENT1");
        condition1.setEventname("event1");
        condition1.setOutput("This is rule1");

        Condition condition2 = new Condition();
        condition2.setField("odometer");
        condition2.setOperator(Condition.Operator.LESS_THAN);
        condition2.setValue(200.0);
        condition2.setValuetype(ValueType.DOUBLE);
        condition2.setOperation(Condition.Operation.OR);
        condition2.setRulename("OVERSPEEDEVENT1");
        condition2.setEventname("movementevent");
        condition2.setOutput("This is rule1");

        Condition condition3 = new Condition();
        condition3.setField("speed");
        condition3.setOperator(Condition.Operator.GREATER_THAN);
        condition3.setValue(40);
        condition3.setValuetype(ValueType.DOUBLE);
        condition3.setOperation(Condition.Operation.OR);
        condition3.setRulename("OVERSPEEDEVENT2");
        condition3.setEventname("event2");
        condition3.setOutput("This is rule2");

        Condition condition4 = new Condition();
        condition4.setField("odometer");
        condition4.setOperator(Condition.Operator.GREATER_THAN);
        condition4.setValue(40000);
        condition4.setValuetype(ValueType.DOUBLE);
        condition4.setOperation(Condition.Operation.OR);
        condition4.setRulename("OVERSPEEDEVENT2");
        condition4.setEventname("movementevent");
        condition4.setOutput("This is rule2");

        listc.add(condition1);
        listc.add(condition2);
        listc.add(condition3);
        listc.add(condition4);
        return listc;
    }


    }
