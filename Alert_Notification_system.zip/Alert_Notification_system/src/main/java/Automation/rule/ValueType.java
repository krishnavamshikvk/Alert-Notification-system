package Automation.rule;

public enum ValueType {


        STRING,
        INTEGER,
        DOUBLE,
        LIST,
        FLOAT,
        DATE
    }
