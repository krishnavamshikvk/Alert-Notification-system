package Automation.Telemetrydata;

public interface Event {
}
