package Automation.Telemetrydata;

import lombok.Data;

@Data
public class MovementSegment implements Event{
    private int speed;

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
