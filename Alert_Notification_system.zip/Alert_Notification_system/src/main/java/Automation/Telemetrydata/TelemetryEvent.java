package Automation.Telemetrydata;

import Automation.event.Event;
import lombok.Data;

@Data
public class TelemetryEvent implements Event {
    private String assetId;
    private MovementSegment movementSegment;
    private LocationSegment locationSegment;

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public LocationSegment getLocationSegment() {
        return locationSegment;
    }

    public void setLocationSegment(LocationSegment locationSegment) {
        this.locationSegment = locationSegment;
    }

    public MovementSegment getMovementSegment() {
        return movementSegment;
    }

    public void setMovementSegment(MovementSegment movementSegment) {
        this.movementSegment = movementSegment;
    }
}
