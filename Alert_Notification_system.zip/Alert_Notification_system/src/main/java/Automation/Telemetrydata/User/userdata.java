package Automation.Telemetrydata.User;

import Automation.Telemetrydata.LocationSegment;
import Automation.Telemetrydata.MovementSegment;
import Automation.Telemetrydata.TelemetryEvent;

import java.util.ArrayList;
import java.util.List;

public class userdata {
    public static List<TelemetryEvent> getuserdata()
    {
        List<TelemetryEvent> listv = new ArrayList<>();

        MovementSegment movementSegment = new MovementSegment();
        movementSegment.setSpeed(50);

        List<String> locations = new ArrayList<>();
        locations.add("a");
        locations.add("b");
        locations.add("c");

        LocationSegment locationSegment = new LocationSegment();
        locationSegment.setLocations(locations);

        TelemetryEvent vehicle1 = new TelemetryEvent();
        vehicle1.setAssetId("MOVE_PER");
        vehicle1.setLocationSegment(locationSegment);
        vehicle1.setMovementSegment(movementSegment);


        listv.add(vehicle1);
        return listv;
    }
}