package Automation.Telemetrydata;

import lombok.Data;

import java.util.List;

@Data
public class LocationSegment implements Event{
    List<String> locations;

    public List<String> getLocations() {
        return locations;
    }

    public void setLocations(List<String> locations) {
        this.locations = locations;
    }
}
