package Automation;


import Automation.Telemetrydata.User.userdata;
import Automation.event.Vehicledataevent;
import Automation.event.Userdataset;
import org.kie.api.KieServices;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.drools.template.ObjectDataCompiler;

import java.util.*;


import Automation.rule.Rule;
import Automation.rule.Ruleset;
import Automation.event.Event;
import Automation.Telemetrydata.TelemetryEvent;

public class Program {


    static public void main(String[] args) throws Exception {

        // Create an event that will be tested against the rule. In reality, the event would be read from some external store.


        List<Vehicledataevent> listv = Userdataset.getuserdataevents();


        List<Rule> ruleset = Ruleset.getruleset();
        // Getting the rules from the Ruleset.
        String drl;
        // AlertDecision alertDecision = evaluate(drl, orderEvent);


        for(int j=0;j< ruleset.size();j++)
        {
            drl = applyRuleTemplate(listv.get(0), ruleset.get(j));
            //drl = applyRuleTemplate(listo.get(0), ruleset);

            for (int i = 0; i < listv.size(); i++) {
                AlertDecision alertDecision = evaluate(drl, listv.get(i));

                System.out.println(alertDecision.getDoAlert());

                if (alertDecision.getDoAlert()) {
                    System.out.println(ruleset.get(j).getOutput());
                }

            }
        }

        // doAlert is false by default


    }



    static private AlertDecision evaluate(String drl, Event event) throws Exception {
        KieServices kieServices = KieServices.Factory.get();
        KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
        kieFileSystem.write("src/main/resources/rule.drl", drl);
        kieServices.newKieBuilder(kieFileSystem).buildAll();

        KieContainer kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
        StatelessKieSession statelessKieSession = kieContainer.getKieBase().newStatelessKieSession();

        AlertDecision alertDecision = new AlertDecision();
        statelessKieSession.getGlobals().set("alertDecision", alertDecision);
        statelessKieSession.execute(event);

        return alertDecision;
    }

    static private String applyRuleTemplate(Event event1, Rule rule) throws Exception {
        Map<String, Object> data = new HashMap<String, Object>();
        ObjectDataCompiler objectDataCompiler = new ObjectDataCompiler();

        data.put("rule",rule);
        data.put("eventType1", event1.getClass().getName());


        return objectDataCompiler.compile(Arrays.asList(data), Thread.currentThread().getContextClassLoader().getResourceAsStream("rule-template.drl"));
    }

}
