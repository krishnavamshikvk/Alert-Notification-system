package Automation.event;

public interface Event {
}
