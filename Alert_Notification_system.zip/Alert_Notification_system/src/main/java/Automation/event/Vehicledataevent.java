package Automation.event;

public class Vehicledataevent implements Event {



    private int speed;
    private long odometer;
    private double tyrePressure;


    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public long getOdometer() {
        return odometer;
    }

    public void setOdometer(long odometer) {
        this.odometer = odometer;
    }

    public double getTyrePressure(double i) {
        return tyrePressure;
    }

    public void setTyrePressure(double tyrePressure) {
        this.tyrePressure = tyrePressure;
    }
}
