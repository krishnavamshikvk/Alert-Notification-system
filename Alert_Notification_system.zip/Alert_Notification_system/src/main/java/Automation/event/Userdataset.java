package Automation.event;

import java.util.ArrayList;
import java.util.List;

public class Userdataset {

    public static List<Vehicledataevent> getuserdataevents() {

        List<Vehicledataevent> listv = new ArrayList<>();
        Vehicledataevent vehicle1 = new Vehicledataevent();
        vehicle1.setSpeed(50);
        vehicle1.setOdometer(30000);
        vehicle1.getTyrePressure(30);

        listv.add(vehicle1);
        return listv;
    }


}
